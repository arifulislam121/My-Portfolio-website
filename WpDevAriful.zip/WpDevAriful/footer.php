<!-- map -->
<div class="map">
	<h3 data-aos="zoom-in" >Locate Me</h3>
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d116760.10157322513!2d90.33657409151844!3d23.86289696798128!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c5d05e7074dd%3A0xd1c58803049f00c7!2sUttara%2C+Dhaka!5e0!3m2!1sen!2sbd!4v1510724450988" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<!-- //map -->

<!-- copyright -->
<div class="copyright-agile">
	<div class="container">
		<h4>Ariful</h4>
		<p>?2017 All rights reserved | Design by <a href="https://www.behance.net/arifulislam233" target="blank">Ariful</a></p>
		<div class="clearfix"></div>
	</div>
</div>
<!-- copyright -->


<!-- Gallery-Tab-JavaScript -->
			<script src="<?php echo get_template_directory_uri(); ?>/assets/js/cbpFWTabs.js"></script>
			<script>
				(function() {
					[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
						new CBPFWTabs( el );
					});
				})();
			</script>
	<!-- Swipe-Box-JavaScript --> 
	<script type="text/javascript">
		jQuery(function($) {
			$(".swipebox").swipebox();
		});
</script>
		<!-- //Swipe-Box-JavaScript -->

	<!--Popup Lightbox Js-->
	<!-- here stars scrolling script -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
	<!-- //here ends scrolling script -->
<!-- //here ends scrolling icon -->


<!-- scrolling script -->
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
		
		$(".img-container").popupLightbox({
			width: 1000,
			height: 800
		});
	});
</script> 
<!-- //scrolling script -->


<!-- //Google Tag Manager -->

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KG75BRK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId            : 'ENTER YOUR APP ID HERE',
      autoLogAppEvents : true,
      xfbml            : true,
      version          : 'v3.2'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<!---Particle js ------->

<style type="text/css"> 
	#home canvas {
    position: absolute;
    top: 0;
}
</style>




<div class="fbmessenger"> 
	<!---Facebook Mssenger ------>
<script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-603b1dac-21fa-49e6-a496-f9240ed0bb8f"></div>
</div>




<a id="toTop" href="#" style="display: inline;">
<span id="toTopHover" style="opacity: 0;"></span>

</a>




<?php wp_footer(); ?> 

</body>
</html>