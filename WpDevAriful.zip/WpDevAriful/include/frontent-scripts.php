<?php


/**
 * Enqueue scripts and styles.
 */
function dev_ariful_scripts() {
   
 
    wp_enqueue_style('swipebox-css',get_theme_file_uri('/assets/css/swipebox.css'),array(),_S_VERSION);
    wp_enqueue_style('aos-css',get_theme_file_uri('/assets/css/aos.css'),array(),_S_VERSION);
    wp_enqueue_style('index-css',get_theme_file_uri('/assets/css/index.css'),array(),_S_VERSION);
    wp_enqueue_style('bootstrap-css',get_theme_file_uri('/assets/css/bootstrap.css'),array(),_S_VERSION);
    wp_enqueue_style('style-css',get_theme_file_uri('/assets/css/style.css'),array(),_S_VERSION);
    wp_enqueue_style('font-awesome-css',get_theme_file_uri('/assets/css/font-awesome.min.css'),array(),_S_VERSION);
    wp_enqueue_style('popup-lightbox-css',get_theme_file_uri('/assets/css/popup-lightbox.css'),array(),_S_VERSION);
    wp_enqueue_style('responsive-css',get_theme_file_uri('/assets/css/responsive.css'),array(),_S_VERSION);
    wp_enqueue_style('owl-carousel-css',get_theme_file_uri('/assets/css/owl.carousel.min.css'),array(),_S_VERSION);
    wp_enqueue_style('owl-theme-css',get_theme_file_uri('/assets/css/owl.theme.min.css'),array(),_S_VERSION);
 
   
//wp_enqueue_style('custom-responsive-css',get_theme_file_uri('/assets/css/custom-responsive.css'),array(),_S_VERSION);
	//root Theme css
	
	wp_enqueue_style( 'wpdevariful-stylesheet', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'wpdevariful-style', 'rtl', 'replace' );



	//---------javascript file from here-------------------//
	
	wp_enqueue_script( 'bootstrap-js', get_theme_file_uri('/assets/js/bootstrap.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'swipebox-js', get_theme_file_uri('/assets/js/jquery.swipebox.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'scrolling-nav-js', get_theme_file_uri('/assets/js/scrolling-nav.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'index-js', get_theme_file_uri('/assets/js/index.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'aos-js', get_theme_file_uri('/assets/js/aos.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'aos1-js', get_theme_file_uri('/assets/js/aos1.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'SmoothScroll-js', get_theme_file_uri('/assets/js/SmoothScroll.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'move-top-js', get_theme_file_uri('/assets/js/move-top.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'easing-js', get_theme_file_uri('/assets/js/easing.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'lightbox-js', get_theme_file_uri('/assets/js/jquery.popup.lightbox.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'jparticle-js', get_theme_file_uri('/assets/js/jparticle.jquery.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'owl-carousel-js', get_theme_file_uri('/assets/js/owl.carousel.min.js'), array('jquery'), _S_VERSION, true );
	

	
	
	// CUSTOM Main JS
	
	wp_enqueue_script( 'main', get_theme_file_uri('/assets/js/main.js'), array('jquery'), _S_VERSION, true );
	//wp_enqueue_script( 'custom-js', get_theme_file_uri('/assets/js/custom.js'), array('jquery'), _S_VERSION, true );

 
 wp_enqueue_script('jquery');
 


}
add_action( 'wp_enqueue_scripts', 'dev_ariful_scripts' );