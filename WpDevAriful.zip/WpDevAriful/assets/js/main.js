(function ($) {
	"use strict";

    jQuery(document).ready(function($){

  // document ready function
  
  
        $(".embed-responsive iframe").addClass("embed-responsive-item");
        $(".carousel-inner .item:first-child").addClass("active");
        
        $('[data-toggle="tooltip"]').tooltip();



    // client work load more btn
	
  var x, size_li;
  function changeLoadCount(media) {
    if (media.matches) {
      x = 6; // no. of items per click mobile <= 767
      $(".gallery-top").hide();
      $(".gallery-top:lt(" + x + ")").show();
      size_li = $(".gallery-top").size();
      if (x == size_li) {
        $(".portfolio-more-btn-wrapper").hide();
      } else {
        $(".portfolio-more-btn-wrapper").show();
      }
    } else {
      x = 6; // no. of items per click in desktop >= 768
      $(".gallery-top").hide();
      $(".gallery-top:lt(" + x + ")").show();
      size_li = $(".gallery-top").size();
      if (x == size_li) {
        $(".portfolio-more-btn-wrapper").hide();
      } else {
        $(".portfolio-more-btn-wrapper").show();
      }
    }
  }

  var media = window.matchMedia("(max-width: 767px)");
  changeLoadCount(media);
  media.addListener(changeLoadCount);
  window.addEventListener("load resize", function () {
    changeLoadCount(media);
    media.addListener(changeLoadCount);
  });

  function loadMore() {
    $(".gallery-top").hide();
    size_li = $(".gallery-top").size();
    $(".gallery-top:lt(" + x + ")").show();
    $(".portfolio-more-btn").click(function () {
      if (media.matches) {
        x = x + 4 <= size_li ? x + 4 : size_li;
      } else {
        x = x + x <= size_li ? x + x : size_li;
      }
      $(".gallery-top:lt(" + x + ")").show();
      if (x == size_li) {
        $(".portfolio-more-btn-wrapper").hide();
      } else {
        $(".portfolio-more-btn-wrapper").show();
      }
    });
  }
  loadMore();
	
	// demo work load more btn
	
	  var x, size_lid;
  function changeLoadCount1(media) {
    if (media.matches) {
      x = 6; // no. of items per click mobile <= 767
      $(".portfolio-ditem").hide();
      $(".portfolio-ditem:lt(" + x + ")").show();
      size_lid = $(".portfolio-ditem").size();
      if (x == size_lid) {
        $(".portfolio-more-btn-dwrapper").hide();
      } else {
        $(".portfolio-more-btn-dwrapper").show();
      }
    } else {
      x = 6; // no. of items per click in desktop >= 768
      $(".portfolio-ditem").hide();
      $(".portfolio-ditem:lt(" + x + ")").show();
      size_lid = $(".portfolio-ditem").size();
      if (x == size_lid) {
        $(".portfolio-more-btn-dwrapper").hide();
      } else {
        $(".portfolio-more-btn-dwrapper").show();
      }
    }
  }

  var media = window.matchMedia("(max-width: 767px)");
  changeLoadCount1(media);
  media.addListener(changeLoadCount1);
  window.addEventListener("load resize", function () {
    changeLoadCount1(media);
    media.addListener(changeLoadCount1);
  });

  function loadMored() {
    $(".portfolio-ditem").hide();
    size_lid = $(".portfolio-ditem").size();
    $(".portfolio-ditem:lt(" + x + ")").show();
    $(".portfolio-more-dbtn").click(function () {
      if (media.matches) {
        x = x + 4 <= size_lid ? x + 4 : size_lid;
      } else {
        x = x + x <= size_lid ? x + x : size_lid;
      }
      $(".portfolio-ditem:lt(" + x + ")").show();
      if (x == size_lid) {
        $(".portfolio-more-btn-dwrapper").hide();
      } else {
        $(".portfolio-more-btn-dwrapper").show();
      }
    });
  }
  loadMored()
  
 // particle js 
 
 
 $("#home").jParticle({
			background: "",
			color: "#fff",
			disableLinks:true,
			disableMouse:false,
			//width:100,
            height:500,
			particle:{
				minSize: 2,
				maxSize: 4
			
			}

		});
		
		
//----testimornial carousel ----//

$("#testimonial-slider").owlCarousel({
        items:2,
        itemsDesktop:[1000,2],
        itemsDesktopSmall:[979,2],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
    });
		
 



    });
    
    
    // window load function


    jQuery(window).load(function(){

        
    });
    
   
  // div slide show by click function 
    
    
    $(window).on("load", function() {
   $(".slide-out").animate({ "left": "-260px" }, "slow" );
   let slideOutVisible = true;
   
   $(".slide-out-tab").click(() => { 
    if (slideOutVisible) {
        $(".slide-out").animate({ "left": "0px" }, "slow" );
        
    } else {
        $(".slide-out").animate({ "left": "-260px" }, "slow" );
    }
    slideOutVisible = !slideOutVisible;
  }); 
});
    
    
    
    


}(jQuery));