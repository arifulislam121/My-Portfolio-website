$(document).ready(function(){
    
    var Loader = document.getElementById('preloader'); //Here you can change the VAR .
    window.addEventListener('load', function(){
        $(Loader).css({'display': 'none'}) // If you change the VAR on the top then you need to change here too .
    })
    
})