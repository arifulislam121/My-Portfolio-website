

//jQuery to collapse the navbar on scroll//
$(window).scroll(function() {
if ($(".navbar").offset().top > 50) {
$(".navbar-fixed-top").addClass("top-nav-collapse");
} else {
$(".navbar-fixed-top").removeClass("top-nav-collapse");
}
});

$(function() {
    $('.page-scroll a').bind('click', function(event) {
        var $anchor = $(this);
        var $section = $($anchor.attr('href'));
        var scrollPos = $section.offset().top + $section.outerHeight() - $(window).height();

        $('html, body').stop().animate({
            scrollTop: scrollPos
        }, 1500, 'easeInOutExpo');

        event.preventDefault();
    });
});