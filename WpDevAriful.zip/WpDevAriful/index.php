<?php get_header(); ?> 
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

<!--preloader-
<div id="preloader"> 
	<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
</div>
--->

<!---preloader end--->

<!-- banner -->
<div class="banner" id="home">
	<div class="agileinfo-dot">
		<div class="container">
		<!-- header -->
		<div class="header-w3layouts"> 
			<!-- Navigation -->
			<nav class="navbar navbar-default navbar-fixed-top"> 
					<div class="navbar-header page-scroll">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">My_Design</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h1><a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">ARIFUL</a></h1>
					</div> 
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav navbar-right cl-effect-15">
							<!-- Hidden li included to remove active class from about link when scrolled up past about section -->
							<li class="hidden"><a class="page-scroll" href="#page-top"></a></li>
							<li><a class="page-scroll scroll" href="#home">Home</a></li>
							<li><a class="page-scroll scroll" href="#about">About</a></li>
							<li><a class="page-scroll scroll" href="#skills">Skills</a></li>
							<li><a class="page-scroll scroll" href="#education">Education & Experience </a></li>
							<li><a class="page-scroll scroll" href="#portfolio">Portfolio</a></li>
								<li><a class="page-scroll scroll" href="#testimornial">Testimornial</a></li>
							<li><a class="page-scroll scroll" href="#contact">Contact</a></li>
						
						</ul>
						
					</div>
					<!-- /.navbar-collapse -->
				<!-- /.container -->
			</nav>  
		</div>	
		<!-- //header -->
		
		
	
		

			<div class="w3_banner_info">
				<div class="w3_banner_info_grid">
					<h2 data-aos="fade-right">Hi, i am </h2>
					<h2 data-aos="fade-right">Ariful Islam.</h2>
					<h5>Web Designer & Developer.</h5>
					<p class="about-header-text">I am a self-taught programmer. A highly experienced and holding a creative back-end web developing experience of 3+ year in a wide range of exciting projects. My rational ideas and work has lead satisfaction to many clients. Iam very passionate about programming.</p>
					<ul data-aos="slide-up">
						<li><a href="#" class="w3ls_more" data-toggle="modal" data-target="#myModal">Know More</a></li>
						<li><a target="_blank" href="<?php echo get_template_directory_uri(); ?>/cv/Resume_of_Ariful_Web_Developer.pdf"><i class="fa fa-download" aria-hidden="true"></i> Download CV</a></li>
					</ul>
				</div>
			</div>
			<div class="thim-click-to-bottom">
				<a href="#about" class="scroll">
					<i class="fa fa-arrows-v" aria-hidden="true"></i>
				</a>
			</div>
		</div>
	</div>
</div>
<!-- banner -->


<!---time show by click ----->


<div class="slide-out">
      <div class="slide-out-tab">
        <div>
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ticking-clock.gif" class="clockimg" alt=""/>
        </div>
      </div>
      <div class="slide-out-content">
        <div class="slide-title"> 
         <div id="MyClockDisplay" class="clock" onload="showTime()"></div>
          
        </div>
      </div>
    </div>


	<script type="text/javascript"> 
        function showTime(){
            var date = new Date();
            var h = date.getHours(); // 0 - 23
            var m = date.getMinutes(); // 0 - 59
            var s = date.getSeconds(); // 0 - 59
            var session = "AM";
            
            if(h == 0){
                h = 12;
            }
            
            if(h > 12){
                h = h - 12;
                session = "PM";
            }
            
            h = (h < 10) ? "0" + h : h;
            m = (m < 10) ? "0" + m : m;
            s = (s < 10) ? "0" + s : s;
            
            var time = h + ":" + m + ":" + s + " " + session;
            document.getElementById("MyClockDisplay").innerText = time;
            document.getElementById("MyClockDisplay").textContent = time;
            
            setTimeout(showTime, 1000);
            
        }

showTime();
</script>


<!----sidebar socila icon ---->

<div class="social-icon-bar">
	<ul>
		<li><a target="blank" href="https://web.facebook.com/ariful.islam.1610"><i class="fa fa-facebook"></i></a></li>
		<li><a target="blank" href="https://www.behance.net/arifulislam233"><i class="fa fa-behance"></i></a></li>
		<li><a target="blank" href="https://github.com/arifulislam121"><i class="fa fa-github"></i></a></li>
		<li><a target="blank" href="https://profiles.wordpress.org/ariful233/"><i class="fa fa-wordpress"></i></a></li>
		<li><a target="blank" href="https://www.linkedin.com/in/md-ariful-islam-291499101/"><i class="fa fa-linkedin"></i></a></li>
	</ul>

</div>





<!-- bootstrap-modal-pop-up -->
	<!-- modal -->
	<div class="modal about-modal fade" id="myModal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header"> 
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
						<h4 class="modal-title">About Me</h4>
				</div> 
				<div class="modal-body">
					<div class="modalpad"> 
						<div class="modalpop ">
							<img src="<?php echo get_template_directory_uri(); ?>/assets/img/popup_img.jpg" class="img-responsive" alt=""/>
						</div>
						<div class="about-modal wthree">
							<h3>Hi, i'm <span>Md. Ariful Islam</span></h3>
							<h4>web designer & developer.</h4>
							<ul class="address">
								<li>
									<ul class="agileits-address-text ">
										<li><b>D.O.B</b></li>
										<li>07-09-1988</li>
									</ul>
								</li>
								<li>
									<ul class="agileits-address-text">
										<li><b>PHONE </b></li>
										<li>+88 01739-044541</li>
									</ul>
								</li>
								<li>
									<ul class="agileits-address-text">
										<li><b>ADDRESS </b></li>
										<li>House No-27,Road- 4/A,Sector-5,Uttara,Dhaka-1230</li>
									</ul>
								</li>
								<li>
									<ul class="agileits-address-text">
										<li><b>E-MAIL </b></li>
										<li><a href="mailto:example@mail.com"> engr.arifulislam777@gmail.com</a></li>
									</ul>
								</li>
								<li>
									<ul class="agileits-address-text">
										<li><b>WEBSITE </b></li>
										<li><a href="https://dev-arifulislamwp.pantheonsite.io/">https://dev-arifulislamwp.pantheonsite.io/ </a></li>
									</ul>
								</li>
							</ul> 
						</div> 
						<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div>
	</div>
	<!-- //modal -->	
<!-- //bootstrap-modal-pop-up --> 

<!-- about -->
<div class="about" id="about">
	<h3 data-aos="zoom-in">About me</h3>
	<div class="col-md-8 about-left">
		<h3 data-aos="slide-up">Hello</h3>
		<p> I am Ariful Islam, a web designer and developer as well as do graphics works too if required for task. I have knowledge on HTML, CSS, Twitter Bootstrap, JavaScript, JQuery for web designing.I have a great experience about PSD to HTML to Wordpress convert,Responsive website design.I have knowledge on wordpress theme customization & development-MSSQL. Currently I use MySQL for back-end with raw PHP for front-end development. </p>

			<p>I am hard working person who can work under pressure. I am a fast learner. Love to learn new system/ technology required in client's project. While working, my aim is to deliver a good work done in less estimated time. I always ready to do a job with great confidence & try my best to produce high quality work for my clients.</p>

			</p>

			<!---<p>I am available through Fiverr <a href="https://www.fiverr.com/arifuldevs" target="blank">(here..)</a>, email, Skype. Regards :).</p>--->
			<img id="sigimg" src="<?php echo get_template_directory_uri(); ?>/assets/img/signaturef.png" alt="" />
			
		</div>

	<div data-aos="flip-right" class="col-md-4 about-right">
		<img id="abtimg" src="<?php echo get_template_directory_uri(); ?>/assets/img/abt-23.png" alt="" class="img-responsive"/>
	</div>
	<div class="clearfix"></div>

	

</div>
<!-- //about -->

<!-- skills -->
<div class="skills" id="skills">
	<div class="container">
				<h3 data-aos="zoom-in">Skills</h3>
		<div class="skill-grids">
			<div class="col-md-6 skill-grids-left">
				<div data-aos="flip-left" class="col-md-6 w3labout-img"> 
				<div class="boxw3-agile"> 
					<img src="<?php echo get_template_directory_uri(); ?>/assets/img/skills/html.jpg" alt="" class="img-responsive" />
					<div class="agile-caption">
						<h3>Html5</h3>
						<p>I have a good knowledge about Html5.</p>
					</div> 
				</div>
				</div>
				<div data-aos="flip-right" class="col-md-6 w3labout-img"> 
				<div class="boxw3-agile"> 
					<img src="<?php echo get_template_directory_uri(); ?>/assets/img/skills/php.jpg" alt="" class="img-responsive" />
					<div class="agile-caption">
						<h3>Php</h3>
						<p>I have a good knowledge about php.</p>
					</div> 
				</div>
				</div>
				<div class="clearfix"></div>
				<div  data-aos="flip-left" class="col-md-6 w3labout-img"> 
				<div class="boxw3-agile"> 
					<img src="<?php echo get_template_directory_uri(); ?>/assets/img/skills/wordpress.png" alt="" class="img-responsive" />
					<div class="agile-caption">
						<h3>Wordpress</h3>
						<p>I have a good knowledge about wordpress.</p>
					</div> 
				</div>
				</div>
				<div data-aos="flip-right" class="col-md-6 w3labout-img"> 
				<div class="boxw3-agile"> 
					<img src="<?php echo get_template_directory_uri(); ?>/assets/img/skills/css3.jpeg" alt="" class="img-responsive" />
					<div class="agile-caption">
						<h3>Css3</h3>
						<p>I have a good knowledge about Css3.</p>
					</div> 
				</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-6 skill-grids-right">
					
			<!-- Skills -->
			<div class="skillbar clearfix " data-percent="80%">
				<div class="skillbar-title" style="background: #ff4f81;"><span>HTML5</span></div>
				<div class="skillbar-bar" style="background: #ff4f81;"></div>
				<div class="skill-bar-percent">100%</div>
			</div> <!-- End Skill Bar -->

			<div class="skillbar clearfix " data-percent="75%">
				<div class="skillbar-title" style="background: #ff9900;"><span>CSS3</span></div>
				<div class="skillbar-bar" style="background: #ff9900;"></div>
				<div class="skill-bar-percent">99%</div>
			</div> <!-- End Skill Bar -->

			<div class="skillbar clearfix " data-percent="80%">
				<div class="skillbar-title" style="background: #146eb4;"><span>Twitter Bootstrap</span></div>
				<div class="skillbar-bar" style="background: #146eb4;"></div>
				<div class="skill-bar-percent">95%</div>
			</div> <!-- End Skill Bar -->

			<div class="skillbar clearfix " data-percent="70%">
				<div class="skillbar-title" style="background: #ff4f81;"><span>Javascript</span></div>
				<div class="skillbar-bar" style="background: #ff4f81;"></div>
				<div class="skill-bar-percent">70%</div>
			</div> <!-- End Skill Bar -->

			<div class="skillbar clearfix " data-percent="70%">
				<div class="skillbar-title" style="background: #8e43e7;"><span>jQuery</span></div>
				<div class="skillbar-bar" style="background: #8e43e7;"></div>
				<div class="skill-bar-percent">80%</div>
			</div> <!-- End Skill Bar -->


			<div class="skillbar clearfix " data-percent="70%">
				<div class="skillbar-title" style="background: #146eb4;"><span>PHP</span></div>
				<div class="skillbar-bar" style="background: #146eb4;"></div>
				<div class="skill-bar-percent">80%</div>
			</div> <!-- End Skill Bar -->

			<div class="skillbar clearfix " data-percent="75%">
				<div class="skillbar-title" style="background: #11b563;"><span>Speed Optimization</span></div>
				<div class="skillbar-bar" style="background: #11b563;"></div>
				<div class="skill-bar-percent">98%</div>
			</div> <!-- End Skill Bar -->

			<div class="skillbar clearfix " data-percent="70%">
				<div class="skillbar-title" style="background: #146eb4;"><span>WordPress Theme Development</span></div>
				<div class="skillbar-bar" style="background: #146eb4;"></div>
				<div class="skill-bar-percent">95%</div>
			</div> <!-- End Skill Bar -->

			
			<!-- //Skills -->
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- //skills -->

	<!-- services section start -->
	

    <!-- services area -->
   <div class="section-padding">
       <div class="container-fluid">
           <div class="row">
               <div class="col-md-8 col-md-offset-2 text-center">
                   <div class="services-text">
                   		<h1 data-aos="zoom-in">Some of My Services</h1>
                       <p>Conveniently whiteboard ubiquitous niche markets and accurate collaboration. <br /> Holisticly supply client-focused models B2B processes.Freelance Web Designer & Developer based in Ariful, Bangladesh. Highly experienced in designing & developing custom Wordpress websites. </p>
                   </div>
               </div>
           </div>
           
           <div class="row text-center services-section">
               <div class="col-md-4">
                   <div class="services-item">
                       <div class="services-icon">
                           <i class="fa fa-laptop"></i>
                       </div>
                       <h3>Proffesional Website Design</h3>
                       <p>My approach to website design is to create a website that strengthens your company’s brand while ensuring ease of use and simplicity for your audience.</p>
                   </div>
               </div>
               <div class="col-md-4">
                   <div class="services-item">
                       <div class="services-icon">
                           <i class="fa fa-globe"></i>
                       </div>
                       <h3>Website Development</h3>
                       <p>The web development process involves taking the graphical elements defined in the design process and coding them into a custom Wordpress theme.</p>
                   </div>
               </div>
               <div class="col-md-4">
                   <div class="services-item">
                       <div class="services-icon">
                           <i class="fa fa-mobile-phone"></i>
                       </div>
                       <h3>Responsive Website Design</h3>
                       <p>Having a responsive layout means that your website fluidly resizes for optimal viewing regardless of the screen size or device (e.g. iPhone, iPad)</p>
                   </div>
               </div>
               <div class="col-md-4">
                   <div class="services-item">
                       <div class="services-icon">
                           <i class="fa fa-wordpress"></i>
                       </div>
                       <h3>Wordpress</h3>
                       <p>WordPress is NO-1 CMS in the World. I can build eCommerce, WooCommerce, Blog, NewsPaper, Technology and any kind of website by using this CMS.</p>
                   </div>
               </div>
               <div class="col-md-4">
                   <div class="services-item">
                       <div class="services-icon">
                           <i class="fa fa-database"></i>
                       </div>
                       <h3>LIFE Time Support</h3>
                       <p>Relationship is most Important in Business. If you work with me,I will give you life time support. When You need any kind of HELP,just contact with me.</p>
                   </div>
               </div>
               <div class="col-md-4">
                   <div class="services-item">
                       <div class="services-icon">
                           <i class="fa fa-code"></i>
                       </div>
                       <h3>Clean Coding</h3>
                       <p>I design in the browser with HTML(5),CSS(3) and a touch of JavaScript.I love coding things from scratch.</p>
                   </div>
               </div>
           </div>
         </div>
      </div>
	<!-- services section start -->








<!-- /education -->
 <div class="education" id="education">
	    <div class="col-md-5 education-w3l">
		     <h3 data-aos="zoom-in" class="w3l_head three">My Education</h3>
			  <div class="education-agile-grids">
				  <div class="education-agile-w3l">
				     <div class="education-agile-w3l-year">
					       <h4>2003-2004</h4>
						   <h6>SSC</h6>
				     </div>
					 <div class="education-agile-w3l-info">
					       <h4>Kalihati R.S.Pilot High School</h4>
						   <p>Kalihati R.S.Pilot high school. there I have past my high school life.</p>
						  
				     </div>
				      <div class="clearfix"></div>
				  </div>
				  <div class="education-agile-w3l two">
				     <div class="education-agile-w3l-year">
					       <h4>2004-2008</h4>
						   <h6>Diplom Engineering Degree</h6>
				     </div>
					 <div class="education-agile-w3l-info">
					       <h4>Tangail Polytechnic Institute</h4>
						   <p>This is the location of govt polytechnic of Tangail district. Name of the polytechnic is Tangail Polytechnic.there has been Six technology. I did complete my study Electrical science engineering technology </p>
						  
				     </div>
				      <div class="clearfix"></div>
				  </div>
				  <div class="education-agile-w3l">
				     <div class="education-agile-w3l-year last">
					       
				     </div>
					 <div class="education-agile-w3l-info last">
					       
						  
				     </div>
				      <div class="clearfix"></div>
				  </div>
				 
			  </div>
		</div>
		
		<div data-aos="slide-up" class="col-md-2 middle">
			<i class="fa fa-hourglass-end" aria-hidden="true"></i>
		</div>
		
	    <div class="col-md-5 education-w3l">
		     <h3 data-aos="zoom-in" class="w3l_head three">My Experience</h3>
			  <div class="education-agile-grids">
				  <div class="education-agile-w3l">
				     <div class="education-agile-w3l-year">
					       <h4>2019-2022</h4>
						   <h6>DesignNearMe (UK)</h6>
				     </div>
					 <div class="education-agile-w3l-info">
					       <h4>Wordpress Developer</h4>
						   <p>I am highly skilled with HTML, CSS, and PSD to HTML,Responsive layout,Javascript,jquery . I have over Two years of experience with each of these technologies</p>
						  
				     </div>
				      <div class="clearfix"></div>
				  </div>
				  <div class="education-agile-w3l two">
				     <div class="education-agile-w3l-year">
					       <h4>2017-2019</h4>
						   <h6>Elance IT(Bangladesh)</h6>
				     </div>
					 <div class="education-agile-w3l-info">
					       <h4>Wordpress Developer</h4>
						   <p>I am highly skilled with PHP, Mysql, and Javascript,wordpress theme development. I have over one years of experience with each of these technologies</p>
						  
				     </div>
				      <div class="clearfix"></div>
				  </div>
				  <div class="education-agile-w3l">
				     <div class="education-agile-w3l-year last">
					       <h4>2016-2017</h4>
						   <h6>NYDTI(Bangladesh)</h6>
				     </div>
					 <div class="education-agile-w3l-info last">
					       <h4>Web Developer</h4>
						  	<p>I am highly skilled with PHP, Mysql, and Javascript,wordpress theme development. I have over one years of experience with each of these technologies</p>
						  
				     </div>
				      <div class="clearfix"></div>
				  </div>
				 
			  </div>
		</div>
		 <div class="clearfix"> </div>
		</div>
 <!-- //education -->
 
 <!-- Portfolio -->
	<div class="portfolio" id="portfolio">
		<h3 data-aos="zoom-in" >Some of my recent work</h3>

		<div class="tabs tabs-style-bar">
			<nav>
				<ul>
					<li><a href="#section-bar-1" class="icon icon-box"><span>Client Project</span></a></li>
					<li><a href="#section-bar-2" class="icon icon-display"><span>My Demo Work</span></a></li>
				</ul>
			</nav>

			<div class="content-wrap">

				<!-- Tab-1 -->
				<section id="section-bar-1" class="agileits w3layouts">
					<h4>Client Project</h4>
					<div style="margin-bottom: 40px;" class="gallery-grids">

					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://aioniccomputerbd.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/aioniccombd.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Aionic Computer BD</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://www.buycryptoacc.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/buycryptoacc.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Buy Crypto ACC</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://nextblockexpo.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/nextblockexpo.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>NextBlockExpo</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://www.petrolyne.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/Petrolyne.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Petrolyne</h4>
								</figcaption>
							</figure>
						</a>
					</div>	
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://www.corsicanaexpresslube.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/Corsicana.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Corsicana Express Lube</h4>
								</figcaption>
							</figure>
						</a>
					</div>	
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://www.bestofutah.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/bestofutah.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Bestofutah</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://mylifeinshambles.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/mylifeinshambles.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>My Life Inshambles</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://nxm-consulting.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/nxm-consulting.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>NXM Consulting</h4>
								</figcaption>
							</figure>
						</a>
					</div>
				<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="http://nahinbd.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/nahinbd.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>NahidBD</h4>
								</figcaption>
							</figure>
						</a>
					</div>	
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://grupomaco.es/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/grupomaco.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Grupo Maco</h4>
								</figcaption>
							</figure>
						</a>
					</div>

					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://onlyfanspropertyinvestment.com.au/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/onlyfanspropertyinvestment.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Onlyfans Property Investment Australia</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://onlyfanspropertyinvestment.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/onlyfanspropertyinvestment1.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Onlyfans Property Investment</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://www.maimyco.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/maimyco.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Mustafa Yildirim</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://revainlab.pro/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/revainlab.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Revain Lab</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://linxlogic.co.uk/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/linxlogic.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Linx Logic</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					
					
					
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://leadershipmonkey.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/leadershipmonkey.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Leader Ship Monkey</h4>
								</figcaption>
							</figure>
						</a>
					</div>				
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://smsfco-living.com.au/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/smsfco-living.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>SMSF Coliving</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://28marketing.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/28marketing.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>28 Marketing</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://zedcourses.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/zedcourses.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Zed Courses</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://usefulmind.ai/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/usefulmind.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Usefulmind</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://eaglelawncare.co/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/eaglelawncare.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Eagle Lawn Care</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://getabox.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/getabox.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Get A Box</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://reliablefeedback.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/reliablefeedback.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Reliable Feedback</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://www.wsto.org/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/wsto.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>WSTO</h4>
								</figcaption>
							</figure>
						</a>
					</div>
					<div class="col-md-4 col-sm-4 gallery-top">
						<a target="_blank" href="https://erectoguide-au.com/">
							<figure class="effect-bubba">
								<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/erectoguide.jpg" alt="" class="img-responsive">
								<figcaption>
									<h4>Erectoguide</h4>
								</figcaption>
							</figure>
						</a>
					</div>



						<div class="clearfix"></div>
					</div>
					
					
<div class="portfolio-more-btn-wrapper">
      <div class="portfolio-more-btn"><span style="background: linear-gradient(90deg, rgba(0, 151, 178, 1) 0%, rgba(126, 217, 87, 1) 100%);padding: 16px;line-height: 50px;color: #fff;font-size: 20px;padding-right: 50px;padding-left: 50px;text-transform: uppercase;cursor: pointer;" class="loadmoredbtn">See More</span></div>
    </div>			
					
					
				</section>
				<!-- //Tab-1 -->

				<!-- Tab-2 -->
				<section id="section-bar-2" class="agileits w3layouts">
					<h4>My Demo Work</h4>
					<div style="margin-bottom: 40px;" class="gallery-grids">
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/modern/ " target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/modern.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/Moose/ " target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/Moose.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/eshopperTheme/" target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/eshopperTheme.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/Notify/" target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/Notify.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/urbanic" target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/urbanic.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/Corporate" target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/Corporate.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/art&portfolio/ " target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/art&portfolio.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						
						<div class="col-md-4 col-sm-4 gallery-top portfolio-ditem">
							<a href="http://portfoliolist.ultimatefreehost.in/" target="_blank">
								<figure class="effect-bubba">
									<img src="<?php echo get_template_directory_uri(); ?>/assets/img/portfolio-image/demo/knscanada.jpg" alt="" class="img-responsive">
									<figcaption>
										<h4>Some Of My Demo Work</h4>
									</figcaption>
								</figure>
							</a>
						</div>
						<div class="clearfix"></div>
						
					</div>
					
	<div class="portfolio-more-btn-dwrapper">
      <div class="portfolio-more-dbtn"><span style="background: linear-gradient(90deg, rgba(0, 151, 178, 1) 0%, rgba(126, 217, 87, 1) 100%);padding: 16px;line-height: 50px;color: #fff;font-size: 20px;padding-right: 50px;padding-left: 50px;text-transform: uppercase;cursor: pointer;" class="loadmoredbtn">See More</span></div>
    </div>		
					
				
				</section>
				<!-- //Tab-2 -->
				
				
			 
				
				
				
			</div><!-- //Content -->
		</div><!-- //Tabs -->
</div>
<!-- //Portfolio -->

<!-- testimornial -->
<div class="contact" id="testimornial">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div id="testimonial-slider" class="owl-carousel">
					<div class="testimonial">
					<h3 class="title">Williamson
					<span class="post">- Web Developer</span>
					</h3>
					<p class="description">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet eum excepturi incidunt laudantium nesciunt omnis, provident repudiandae rerum sed! Amet blanditiis eaque eu!
					</p>
					</div>
					<div class="testimonial">
					<h3 class="title">Kristina
					<span class="post">- Web Designer</span>
					</h3>
					<p class="description">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet eum excepturi incidunt laudantium nesciunt omnis, provident repudiandae rerum sed! Amet blanditiis eaque eu!
					</p>
					</div>
					<div class="testimonial">
					<h3 class="title">Steve Thomas
					<span class="post">- Web Developer</span>
					</h3>
					<p class="description">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet eum excepturi incidunt laudantium nesciunt omnis, provident repudiandae rerum sed! Amet blanditiis eaque eu!
					</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<!-- contact -->
<div class="contact" id="contact">
	<div class="container">
		<div class="col-md-6 contact-left">
			<h3 data-aos="zoom-in" >contact me</h3>
				<p>Freelance Web Designer & Developer based in ariful, Bangladesh.Highly experienced in designing & developing custom Wordpress websites.</p>
			<form action="#" method="post">
					<div class="col-md-6 agileits_agile_about_mail_left">
						<input type="text" name="Name" placeholder="Name" required="">
						<input type="text" name="Subject" placeholder="Company Name" required="">
					</div>
					<div class="col-md-6 agileits_agile_about_mail_left">
						<input type="email" name="Email" placeholder="Email" required="">
						<input type="text" name="Phone" placeholder="Phone" required="">
					</div>
				<div class="clearfix"> </div>
				<textarea name="Message" placeholder="Message..." required=""></textarea>
				<input type="submit" value="Submit">
			</form>
		</div>
		<div class="col-md-6 contact-right">
			<div data-aos="flip-down" class="col-md-6 contactright1">
			<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
			<h4>Location</h4>
			<p>House No-27, Road- 4/A, Sector-5, Uttara, Dhaka-1230. - Dhaka </p>
			</div>
			<div data-aos="flip-down" class="col-md-6 contactright1">
			<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
			<h4>Phone</h4>
			<p>+88 01739-044541</p>
			<p>+88 01837-100291</p>
			</div>
			<div class="clearfix"></div>
			<div data-aos="flip-up"class="col-md-6 contactright1">
			<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
			<h4>Support</h4>
			<p><a href="mailto:engr.arifulislam777@gmail.com">engr.arifulislam777@gmail.com</a></p>
			</div>
			<div data-aos="flip-up" class="col-md-6 contactright1">
			<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
			<h4>Mail</h4>
			<p><a href="mailto:engr.arifulislam777@gmail.com">engr.arifulislam777@gmail.com</a></p>
			</div>
			<div class="clearfix"></div>
			<ul class="top-links">
				<li data-aos="flip-right"><a href="https://www.facebook.com/ariful.islam.1610" target="blank"><i class="fa fa-facebook"></i></a></li>
				<li data-aos="flip-right"><a href="https://twitter.com/Mdarifu72557989" target="blank"><i class="fa fa-twitter"></i></a></li>
				<li data-aos="flip-right"><a href="https://plus.google.com/u/0/+ArifulIslamariful" target="blank"><i class="fa fa-google-plus"></i></a></li>
				<li data-aos="flip-right"><a href="https://www.linkedin.com/in/md-ariful-islam-291499101/" target="blank"><i class="fa fa-linkedin"></i></a></li>
				<li data-aos="flip-right"><a href="https://www.tumblr.com/dashboard" target="blank"><i class="fa fa-tumblr"></i></a></li>
			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- //contact -->

<?php get_footer(); ?>