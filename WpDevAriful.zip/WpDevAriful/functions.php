<?php


if ( ! defined( '_S_VERSION' ) ) {

	define( '_S_VERSION', '1.0.0' );
}


//remove unnecessary class id from wp nav menu


/*
	add_filter('nav_menu_item_id', 'clear_nav_menu_item_id', 10, 3);
	function clear_nav_menu_item_id($id, $item, $args) {
		return "";
	}

	add_filter('nav_menu_css_class', 'clear_nav_menu_item_class', 10, 3);
	function clear_nav_menu_item_class($classes, $item, $args) {
		return array();
	}
*/

//current menu active

add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

function special_nav_class ($classes, $item) {
  if (in_array('current-menu-item', $classes) ){
    $classes[] = 'current ';
  }
  return $classes;
}


//============contact form7 submit button tag or style replace and customize function ===================//

/*
	//removing default submit tag//
	remove_action('wpcf7_init', 'wpcf7_add_form_tag_submit');

	//adding action with function which handles our button markup//
	add_action('wpcf7_init', 'twentysixteen_child_cf7_button');

	//adding out submit button tag//
	if (!function_exists('twentysixteen_child_cf7_button')) {
		function twentysixteen_child_cf7_button() {
		wpcf7_add_form_tag('submit', 'twentysixteen_child_cf7_button_handler');
		}
	}

	//out button markup inside handler//
	if (!function_exists('twentysixteen_child_cf7_button_handler')) {
		function twentysixteen_child_cf7_button_handler($tag) {
			$tag = new WPCF7_FormTag($tag);
			$class = wpcf7_form_controls_class($tag->type);
			$atts = array();
			$atts['class'] = $tag->get_class_option($class);
			$atts['class'] .= 'site-btn';
			$atts['id'] = $tag->get_id_option();
			$atts['tabindex'] = $tag->get_option('tabindex', 'int', true);
			$value = isset($tag->values[0]) ? $tag->values[0] : '';
			if (empty($value)) {
			$value = esc_html__('GET FREE QUOTE', 'twentysixteen');
			}
			$atts['type'] = 'submit';
			$atts = wpcf7_format_atts($atts);
			$html = sprintf('<button type="submit" class="site-btn">%s<i class="fal fa-angle-right"></i></button>',$value,$atts);
			return $html;
		}
	}

*/


//=== Remove auto p from Contact Form 7 shortcode output====//

/*
	add_filter('wpcf7_autop_or_not', 'wpcf7_autop_return_false');
	function wpcf7_autop_return_false() {
		return false;
	}
*



/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
add_theme_support( 'title-tag' );



require get_template_directory() . '/include/after-setup.php';

require get_template_directory().  '/include/frontent-scripts.php';


//=========================Portfolio Custom Post========================//



	add_action( 'init', 'custom_post_type' );

	function custom_post_type() {
	 
	// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => _x( 'Portfolio', 'Post Type General Name', 'wpariful' ),
			'singular_name'       => _x( 'Portfolio', 'Post Type Singular Name', 'wpariful' ),
			'menu_name'           => __( 'Portfolio', 'wpariful' ),
			'parent_item_colon'   => __( 'Parent Portfolio', 'wpariful' ),
			'all_items'           => __( 'All Portfolio', 'wpariful' ),
			'view_item'           => __( 'View Portfolio', 'wpariful' ),
			'add_new_item'        => __( 'Add New Portfolio', 'wpariful' ),
			'add_new'             => __( 'Add New', 'wpariful' ),
			'edit_item'           => __( 'Edit Portfolio', 'wpariful' ),
			'update_item'         => __( 'Update Portfolio', 'wpariful' ),
			'search_items'        => __( 'Search Portfolio', 'wpariful' ),
			'not_found'           => __( 'Not Found', 'wpariful' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'wpariful' ),
		);
		 
	// Set other options for Custom Post Type
		 
		$args = array(
			'label'               => __( 'Portfolio', 'wpariful' ),
			'labels'              => $labels,
			// Features this CPT supports in Post Editor
			'supports'            => array( 'title','thumbnail', 'custom-fields'),
			// You can associate this CPT with a taxonomy or custom taxonomy. 
			'taxonomies'          => array( 'portfolio_category' ),
			// A hierarchical CPT is like Pages and can have//
			// Parent and child items. A non-hierarchical CPT
			//is like Posts.//
			
			'hierarchical'        => true,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'show_in_rest' => true,
	 
		);
		 
		// Registering your Custom Post Type
		register_post_type( 'ariful_Portfolio', $args );
	 
	}


	// ---------Create Service Custom Taxonomy----//


	add_action( 'init', 'create_topics_nonhierarchical_taxonomy', 0 );
	 
	function create_topics_nonhierarchical_taxonomy() {
	 
	// Labels part for the GUI
	 
	  $labels = array(
		'name' => _x( 'Portfolio Category', 'taxonomy general name' ),
		'singular_name' => _x( 'Portfolio Category', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Portfolio Category' ),
		'popular_items' => __( 'Popular Portfolio Category' ),
		'all_items' => __( 'All Portfolio Category' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Portfolio Category' ), 
		'update_item' => __( 'Update Portfolio Category' ),
		'add_new_item' => __( 'Add New Portfolio Category' ),
		'new_item_name' => __( 'New Portfolio Category Name' ),
		'separate_items_with_commas' => __( 'Separate topics with commas' ),
		'add_or_remove_items' => __( 'Add or remove topics' ),
		'choose_from_most_used' => __( 'Choose from the most used topics' ),
		'menu_name' => __( 'Portfolio Category' ),
	  ); 
	 
	// Now register the non-hierarchical taxonomy like tag
	 
	  register_taxonomy('portfolio_category','ariful_Portfolio',array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'show_admin_column' => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var' => true,
		'rewrite' => array( 'slug' => 'portfolio_category' ),
	  ));
	}


function amara_meta_box_banabo(){
	
	add_meta_box(
	'favourite_food',
	'What is your favourite food?',
	'meta_box_er_output',
	'ariful_Portfolio',
	'post',
	'normal'
	);
		add_meta_box(
	'favourite_naika',
	'What is your favourite naika?',
	'onno_areakta_output',
	'post',
	'normal'
	);
	
}

add_action('add_meta_boxes','amara_meta_box_banabo');



function meta_box_er_output($post){ ?>
	<label for="food">please type your favourite food</label>
	<p><input class="widefat" id="food" type="text" name="favourite" placeholder="favourite food"
	value="<?php echo get_post_meta($post->ID,'favourite',true);?>"/></p>
	
	
	<label for="poet">please type your favourite poet</label>
	<p><input class="widefat" id="poet" type="text" name="ami" placeholder="favourite poet"
	value="<?php echo get_post_meta($post->ID,'ami',true);?>"/></p>
	
	<!---get_the_ID()---use if not work $post->ID--->

<?php }

function onno_areakta_output($post){ ?>
	<label for="food">please type your favourite food</label>
	<p><input class="widefat" id="food" type="text" name="favourite" placeholder="favourite food"
	value="<?php echo get_post_meta($post->ID,'favourite',true);?>"/></p>
	
	
	<label for="poet">please type your favourite poet</label>
	<p><input class="widefat" id="poet" type="text" name="ami" placeholder="favourite poet"
	value="<?php echo get_post_meta($post->ID,'ami',true);?>"/></p>

<?php }



function Dtabase_a_pathabo($post_id){
	
	update_post_meta($post_id,'favourite',$_POST['favourite']);
	update_post_meta($post_id,'ami',$_POST['ami']);
}

add_action('save_post','Dtabase_a_pathabo');




 function defaults_menu()
        {

            echo ' <ul>
	      <li><a href="' . home_url() . '" title="Home">Home</a></li>
	      </ul>';
        }